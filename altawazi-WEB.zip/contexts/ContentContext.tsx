import React, { createContext, useContext, useState, useEffect } from 'react';
import { ContentContextType, WebsiteContent, Language, ProjectItem, ServiceItem } from '../types';
import { translations as defaultTranslations } from '../translations';

const ContentContext = createContext<ContentContextType | undefined>(undefined);

const STORAGE_KEY = 'tawazi_content_v1';

const defaultProjects: ProjectItem[] = [
  { id: 1, title: "فيلا النرجس السكنية", category: "residential", imageUrl: "https://images.unsplash.com/photo-1600596542815-27838eb76ed4?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
  { id: 2, title: "برج الأعمال التجارية", category: "commercial", imageUrl: "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
  { id: 3, title: "تجديد واجهة كلاسيكية", category: "restoration", imageUrl: "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
  { id: 4, title: "مجمع سكني حديث", category: "residential", imageUrl: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
  { id: 5, title: "تشطيب داخلي فاخر", category: "decor", imageUrl: "https://images.unsplash.com/photo-1618221195710-dd6b41faaea6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
  { id: 6, title: "مول التسوق المركزي", category: "commercial", imageUrl: "https://images.unsplash.com/photo-1519567241046-7f570eee3c9e?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
  { id: 7, title: "تصميم داخلي للمكاتب", category: "decor", imageUrl: "https://images.unsplash.com/photo-1497366216548-37526070297c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
  { id: 8, title: "ترميم قصر تاريخي", category: "restoration", imageUrl: "https://images.unsplash.com/photo-1464146072230-91cabc968266?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
  { id: 9, title: "فيلا مودرن", category: "residential", imageUrl: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
];

const defaultServices: ServiceItem[] = [
  { id: 1, title: "general", description: "general", iconName: "Home" },
  { id: 2, title: "restoration", description: "restoration", iconName: "Hammer" },
  { id: 3, title: "finishing", description: "finishing", iconName: "PaintBucket" },
  { id: 4, title: "design", description: "design", iconName: "PencilRuler" },
  { id: 5, title: "mep", description: "mep", iconName: "Zap" },
  { id: 6, title: "management", description: "management", iconName: "Truck" }
];

const defaultContent: WebsiteContent = {
  translations: defaultTranslations,
  projects: defaultProjects,
  services: defaultServices,
  heroImage: "https://images.unsplash.com/photo-1541888946425-d81bb19240f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80"
};

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [content, setContent] = useState<WebsiteContent>(defaultContent);
  const [isLoaded, setIsLoaded] = useState(false);

  // Load from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        // Merge with default to ensure new keys exist if schema changes
        setContent({ ...defaultContent, ...parsed });
      } catch (e) {
        console.error("Failed to load content", e);
      }
    }
    setIsLoaded(true);
  }, []);

  const saveChanges = () => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(content));
    alert("Changes saved successfully!");
  };

  const updateTranslation = (lang: Language, section: string, key: string, value: string) => {
    setContent(prev => ({
      ...prev,
      translations: {
        ...prev.translations,
        [lang]: {
          ...prev.translations[lang],
          [section]: {
            ...prev.translations[lang][section],
            [key]: value
          }
        }
      }
    }));
  };

  // Helper to update deep keys like 'items.general.title'
  const updateNestedTranslation = (lang: Language, path: string[], value: string) => {
    setContent(prev => {
      const newTranslations = JSON.parse(JSON.stringify(prev.translations));
      let current = newTranslations[lang];
      
      for (let i = 0; i < path.length - 1; i++) {
        current = current[path[i]];
      }
      
      current[path[path.length - 1]] = value;
      
      return {
        ...prev,
        translations: newTranslations
      };
    });
  };

  const updateHeroImage = (url: string) => {
    setContent(prev => ({ ...prev, heroImage: url }));
  };

  const addProject = (project: Omit<ProjectItem, 'id'>) => {
    const newId = Math.max(0, ...content.projects.map(p => p.id)) + 1;
    setContent(prev => ({
      ...prev,
      projects: [...prev.projects, { ...project, id: newId }]
    }));
  };

  const deleteProject = (id: number) => {
    setContent(prev => ({
      ...prev,
      projects: prev.projects.filter(p => p.id !== id)
    }));
  };

  const updateProject = (project: ProjectItem) => {
     setContent(prev => ({
      ...prev,
      projects: prev.projects.map(p => p.id === project.id ? project : p)
    }));
  };

  const resetToDefaults = () => {
    if (window.confirm("Are you sure you want to reset all content to default? This cannot be undone.")) {
      setContent(defaultContent);
      localStorage.removeItem(STORAGE_KEY);
      window.location.reload();
    }
  };

  if (!isLoaded) return null;

  return (
    <ContentContext.Provider value={{
      content,
      updateTranslation,
      updateNestedTranslation,
      updateHeroImage,
      addProject,
      deleteProject,
      updateProject,
      saveChanges,
      resetToDefaults
    }}>
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const context = useContext(ContentContext);
  if (!context) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};