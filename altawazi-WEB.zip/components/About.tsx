import React from 'react';
import { ShieldCheck, Users, Clock, Award } from 'lucide-react';
import { Language } from '../types';
import { useContent } from '../contexts/ContentContext';

interface AboutProps {
  language: Language;
}

const About: React.FC<AboutProps> = ({ language }) => {
  const { content } = useContent();
  const t = content.translations[language].about;
  
  const stats = [
    { icon: <ShieldCheck size={32} />, label: t.stats.projects, value: '+150' },
    { icon: <Users size={32} />, label: t.stats.clients, value: '+120' },
    { icon: <Clock size={32} />, label: t.stats.experience, value: '+10' },
    { icon: <Award size={32} />, label: t.stats.awards, value: '5' },
  ];

  return (
    <section className="py-20 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          
          {/* Image Content - Visually mirrored based on direction */}
          <div className="w-full lg:w-1/2 relative">
            <div className={`absolute -top-4 w-24 h-24 bg-sky-100 rounded-full -z-10 ${language === 'ar' ? '-right-4' : '-left-4'}`}></div>
            <div className={`absolute -bottom-4 w-32 h-32 bg-slate-100 rounded-full -z-10 ${language === 'ar' ? '-left-4' : '-right-4'}`}></div>
            <div className="relative rounded-2xl overflow-hidden shadow-2xl transform rotate-2 hover:rotate-0 transition-transform duration-500">
              <img 
                src="https://images.unsplash.com/photo-1504307651254-35680f356dfd?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80" 
                alt="Construction Site" 
                className="w-full h-[500px] object-cover"
              />
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/70 to-transparent p-6">
                <p className="text-white font-bold text-lg">{t.imageOverlay}</p>
              </div>
            </div>
            {/* Floating Badge */}
            <div className={`absolute top-10 bg-sky-500 text-white p-4 rounded-lg shadow-lg font-bold text-center animate-pulse ${language === 'ar' ? 'left-10' : 'right-10'}`}>
              <span className="block text-2xl">10+</span>
              <span className="text-xs uppercase tracking-wider">{t.experienceBadge}</span>
            </div>
          </div>

          {/* Text Content */}
          <div className="w-full lg:w-1/2 text-start">
            <div className="inline-block px-3 py-1 bg-sky-100 text-sky-600 rounded-full text-sm font-semibold mb-4">
              {t.badge}
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6 leading-tight">
              {t.titlePrefix} <br />
              <span className="text-sky-500">{t.titleSuffix}</span>
            </h2>
            <p className="text-slate-600 mb-6 leading-relaxed text-lg">
              {t.description1}
            </p>
            <p className="text-slate-600 mb-8 leading-relaxed">
              {t.description2}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 mt-8">
              {stats.map((stat, idx) => (
                <div key={idx} className="flex flex-col items-center p-4 bg-slate-50 rounded-xl hover:bg-white hover:shadow-md transition-all duration-300 border border-slate-100">
                  <div className="text-sky-500 mb-2">{stat.icon}</div>
                  <span className="text-2xl font-bold text-slate-900 block">{stat.value}</span>
                  <span className="text-sm text-slate-500 text-center">{stat.label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;