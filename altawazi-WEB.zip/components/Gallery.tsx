import React, { useState } from 'react';
import { Language } from '../types';
import { useContent } from '../contexts/ContentContext';

interface GalleryProps {
  language: Language;
}

const Gallery: React.FC<GalleryProps> = ({ language }) => {
  const [activeFilter, setActiveFilter] = useState("all");
  const { content } = useContent();
  const t = content.translations[language].gallery;

  // Helper to get category label safely
  const getCategoryLabel = (key: string) => {
    return (t.categories as any)[key] || key;
  };

  const categoryKeys = ["all", "residential", "commercial", "restoration", "decor"];

  const filteredProjects = activeFilter === "all" 
    ? content.projects 
    : content.projects.filter(p => p.category === activeFilter);

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">{t.title}</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            {t.description}
          </p>
        </div>

        {/* Filter Tabs */}
        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {categoryKeys.map((key) => (
            <button
              key={key}
              onClick={() => setActiveFilter(key)}
              className={`px-6 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                activeFilter === key
                  ? 'bg-sky-500 text-white shadow-md transform scale-105'
                  : 'bg-white text-slate-600 hover:bg-gray-200'
              }`}
            >
              {getCategoryLabel(key)}
            </button>
          ))}
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => (
            <div key={project.id} className="group relative overflow-hidden rounded-xl shadow-lg bg-white cursor-pointer">
              <div className="aspect-w-4 aspect-h-3">
                <img 
                  src={project.imageUrl} 
                  alt={project.title}
                  className="w-full h-64 object-cover transform group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <div className="absolute inset-0 bg-slate-900/70 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center text-center p-4">
                <span className="text-sky-500 font-medium text-sm uppercase tracking-wider mb-2 translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-75">
                  {getCategoryLabel(project.category)}
                </span>
                <h3 className="text-white text-xl font-bold translate-y-4 group-hover:translate-y-0 transition-transform duration-300 delay-100">
                  {project.title}
                </h3>
              </div>
            </div>
          ))}
          {filteredProjects.length === 0 && (
             <div className="col-span-full text-center text-gray-500 py-10">
                No projects found in this category.
             </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Gallery;