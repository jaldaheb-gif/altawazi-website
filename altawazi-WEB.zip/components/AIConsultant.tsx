import React, { useState, useRef, useEffect } from 'react';
import { MessageSquare, X, Send, Loader2, Bot } from 'lucide-react';
import { generateConsultationResponse } from '../services/geminiService';
import { ChatMessage, Language } from '../types';
import { useContent } from '../contexts/ContentContext';

interface AIConsultantProps {
  language: Language;
}

const AIConsultant: React.FC<AIConsultantProps> = ({ language }) => {
  const { content } = useContent();
  const t = content.translations[language].ai;
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: t.welcome }
  ]);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Reset chat when language changes
  useEffect(() => {
    setMessages([{ role: 'model', text: t.welcome }]);
  }, [language, t.welcome]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMsg = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
      const responseText = await generateConsultationResponse(userMsg, language);
      setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (error) {
      setMessages(prev => [...prev, { role: 'model', text: t.error, isError: true }]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className={`fixed bottom-6 z-50 flex flex-col items-start font-sans ${language === 'ar' ? 'left-6' : 'right-6'}`}>
      {/* Chat Window */}
      {isOpen && (
        <div className="mb-4 w-[350px] sm:w-[400px] h-[500px] bg-white rounded-2xl shadow-2xl border border-gray-200 flex flex-col overflow-hidden animate-fade-in-up">
          {/* Header */}
          <div className="bg-slate-900 text-white p-4 flex justify-between items-center">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-sky-500 rounded-full text-white">
                <Bot size={20} />
              </div>
              <div>
                <h3 className="font-bold text-sm">{t.title}</h3>
                <span className="text-xs text-gray-300 flex items-center gap-1">
                  <span className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></span>
                  {t.online}
                </span>
              </div>
            </div>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-gray-400 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Messages Area */}
          <div className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-4 text-start">
            {messages.map((msg, idx) => (
              <div 
                key={idx} 
                className={`flex ${msg.role === 'user' ? 'justify-start' : 'justify-end'}`}
              >
                <div 
                  className={`max-w-[80%] p-3 rounded-2xl text-sm leading-relaxed ${
                    msg.role === 'user' 
                      ? `bg-sky-500 text-white ${language === 'ar' ? 'rounded-tr-none' : 'rounded-tl-none'}` 
                      : `bg-white border border-gray-200 text-gray-700 shadow-sm ${language === 'ar' ? 'rounded-tl-none' : 'rounded-tr-none'}`
                  } ${msg.isError ? 'border-red-500 bg-red-50 text-red-600' : ''}`}
                >
                  {msg.text}
                </div>
              </div>
            ))}
            {loading && (
              <div className="flex justify-end">
                <div className={`bg-white p-3 rounded-2xl shadow-sm border border-gray-200 ${language === 'ar' ? 'rounded-tl-none' : 'rounded-tr-none'}`}>
                  <Loader2 className="animate-spin text-sky-500" size={20} />
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Area */}
          <div className="p-3 bg-white border-t border-gray-100 flex gap-2 items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyPress}
              placeholder={t.placeholder}
              className="flex-1 px-4 py-2 bg-gray-100 border-0 rounded-full focus:ring-2 focus:ring-sky-500 focus:bg-white transition-all text-sm outline-none"
              disabled={loading}
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || loading}
              className={`p-2 bg-slate-900 text-white rounded-full hover:bg-slate-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors ${language === 'ar' ? '' : 'rotate-180'}`}
            >
              <Send size={18} />
            </button>
          </div>
        </div>
      )}

      {/* Toggle Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className={`${isOpen ? 'scale-0' : 'scale-100'} transition-transform duration-300 bg-slate-900 hover:bg-slate-800 text-white p-4 rounded-full shadow-lg flex items-center justify-center gap-2 group`}
      >
        <MessageSquare size={24} />
        <span className="max-w-0 overflow-hidden group-hover:max-w-[150px] transition-all duration-300 whitespace-nowrap text-sm font-medium">
          {t.toggle}
        </span>
      </button>
    </div>
  );
};

export default AIConsultant;