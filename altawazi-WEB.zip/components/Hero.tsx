import React from 'react';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { Page, Language } from '../types';
import { useContent } from '../contexts/ContentContext';

interface HeroProps {
  setPage: (page: Page) => void;
  language: Language;
}

const Hero: React.FC<HeroProps> = ({ setPage, language }) => {
  const { content } = useContent();
  const t = content.translations[language].hero;

  return (
    <div className="relative h-screen w-full overflow-hidden flex items-center justify-center">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat scale-105 animate-[subtle-zoom_20s_infinite_alternate]"
        style={{ backgroundImage: `url("${content.heroImage}")` }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-r from-slate-900/90 via-slate-900/70 to-slate-900/30"></div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center sm:text-start w-full">
        <div className={`max-w-3xl animate-fade-in-up ${language === 'ar' ? 'mr-auto' : 'ml-auto'}`}>
          <h2 className="text-sky-500 font-bold text-lg sm:text-xl tracking-wider mb-4 uppercase">
            {t.subtitle}
          </h2>
          <h1 className="text-4xl sm:text-5xl md:text-7xl font-extrabold text-white leading-tight mb-6">
            {t.titlePrefix} <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-l from-sky-400 to-sky-600">
              {t.titleSuffix}
            </span>
          </h1>
          <p className={`text-lg sm:text-xl text-gray-300 mb-8 leading-relaxed max-w-2xl ${language === 'ar' ? 'mr-auto' : 'ml-auto'}`}>
            {t.description}
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center sm:justify-start">
            <button 
              onClick={() => setPage(Page.CONTACT)}
              className="group px-8 py-4 bg-sky-500 hover:bg-sky-600 text-white font-bold rounded-lg transition-all duration-300 transform hover:-translate-y-1 shadow-lg shadow-sky-500/20 flex items-center justify-center gap-2"
            >
              {t.ctaPrimary}
              {language === 'ar' ? (
                <ArrowLeft className="group-hover:-translate-x-1 transition-transform" />
              ) : (
                <ArrowRight className="group-hover:translate-x-1 transition-transform" />
              )}
            </button>
            <button 
              onClick={() => setPage(Page.GALLERY)}
              className="px-8 py-4 bg-transparent border-2 border-white text-white font-bold rounded-lg hover:bg-white hover:text-slate-900 transition-all duration-300 flex items-center justify-center"
            >
              {t.ctaSecondary}
            </button>
          </div>
        </div>
      </div>
      
      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce text-white/50">
        <div className="w-6 h-10 border-2 border-white/30 rounded-full flex justify-center p-1">
            <div className="w-1 h-2 bg-white/70 rounded-full animate-[scroll-down_1.5s_infinite]"></div>
        </div>
      </div>
    </div>
  );
};

export default Hero;