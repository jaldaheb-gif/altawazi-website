import React, { useState, useEffect } from 'react';
import { Menu, X, Globe, Building2 } from 'lucide-react';
import { Page, Language } from '../types';
import { useContent } from '../contexts/ContentContext';

interface NavbarProps {
  currentPage: Page;
  setPage: (page: Page) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
}

const Navbar: React.FC<NavbarProps> = ({ currentPage, setPage, language, setLanguage }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const { content } = useContent();
  const t = content.translations[language].navbar;

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: Page.HOME, label: t.links[Page.HOME] },
    { id: Page.ABOUT, label: t.links[Page.ABOUT] },
    { id: Page.SERVICES, label: t.links[Page.SERVICES] },
    { id: Page.GALLERY, label: t.links[Page.GALLERY] },
    { id: Page.CONTACT, label: t.links[Page.CONTACT] },
  ];

  const handleNavClick = (page: Page) => {
    setPage(page);
    setIsMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const toggleLanguage = () => {
    setLanguage(language === 'ar' ? 'en' : 'ar');
    setIsMenuOpen(false);
  };

  return (
    <nav 
      className={`fixed top-0 w-full z-40 transition-all duration-300 ${
        scrolled ? 'bg-white/95 backdrop-blur-md shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          
          {/* Logo */}
          <div 
            className="flex items-center gap-3 cursor-pointer group" 
            onClick={() => handleNavClick(Page.HOME)}
          >
            <div className="w-12 h-12 bg-gradient-to-br from-sky-500 to-sky-700 rounded-xl flex items-center justify-center text-white shadow-lg transform group-hover:rotate-6 transition-transform duration-300">
              <Building2 size={26} strokeWidth={1.5} />
            </div>
            <div className="flex flex-col">
              <span className={`text-xl font-bold leading-none ${scrolled ? 'text-slate-900' : 'text-white'}`}>
                {language === 'ar' ? 'مؤسسة التوازي الحديثة' : 'Modern Tawazi'}
              </span>
              <span className={`text-xs font-medium tracking-wide ${scrolled ? 'text-slate-600' : 'text-gray-300'}`}>
                {t.brandSubtitle}
              </span>
            </div>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-1 space-x-reverse rtl:space-x-reverse ltr:space-x-normal gap-1">
            {navLinks.map((link) => (
              <button
                key={link.id}
                onClick={() => handleNavClick(link.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-300 ${
                  currentPage === link.id
                    ? 'bg-sky-500 text-white shadow-lg scale-105'
                    : scrolled 
                      ? 'text-slate-700 hover:bg-gray-100' 
                      : 'text-white hover:bg-white/10'
                }`}
              >
                {link.label}
              </button>
            ))}
            
            {/* Language Switcher */}
            <button
              onClick={toggleLanguage}
              className={`flex items-center gap-1 px-3 py-2 rounded-full text-sm font-medium transition-all duration-300 border ${
                scrolled 
                  ? 'text-slate-700 border-slate-200 hover:bg-gray-100' 
                  : 'text-white border-white/30 hover:bg-white/10'
              } mx-2`}
            >
              <Globe size={16} />
              <span>{language === 'ar' ? 'EN' : 'عربي'}</span>
            </button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center gap-2">
            <button
              onClick={toggleLanguage}
              className={`p-2 rounded-md transition-colors ${scrolled ? 'text-slate-900' : 'text-white'}`}
            >
              <span className="font-bold text-sm">{language === 'ar' ? 'EN' : 'عربي'}</span>
            </button>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className={`p-2 rounded-md transition-colors ${scrolled ? 'text-slate-900' : 'text-white'}`}
            >
              {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      <div 
        className={`md:hidden fixed inset-0 z-30 bg-slate-900/95 backdrop-blur-sm transform transition-transform duration-300 ease-in-out ${
          isMenuOpen ? 'translate-x-0' : (language === 'ar' ? '-translate-x-full' : 'translate-x-full')
        }`}
        style={{ top: '0', [language === 'ar' ? 'right' : 'left']: isMenuOpen ? '0' : '-100%', width: '75%', height: '100vh' }}
      >
        <div className="flex flex-col p-8 space-y-6 mt-16">
            <div className="text-white text-xl font-bold border-b border-gray-700 pb-4 mb-2 text-start">
                {t.menuTitle}
            </div>
          {navLinks.map((link) => (
            <button
              key={link.id}
              onClick={() => handleNavClick(link.id)}
              className={`text-start text-lg font-medium transition-colors ${
                currentPage === link.id ? 'text-sky-500' : 'text-gray-300 hover:text-white'
              }`}
            >
              {link.label}
            </button>
          ))}
        </div>
      </div>
      
      {/* Overlay backdrop for mobile menu */}
      {isMenuOpen && (
        <div 
            className="md:hidden fixed inset-0 bg-black/50 z-20"
            onClick={() => setIsMenuOpen(false)}
        ></div>
      )}
    </nav>
  );
};

export default Navbar;