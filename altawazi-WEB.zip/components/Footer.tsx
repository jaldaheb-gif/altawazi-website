import React from 'react';
import { Facebook, Twitter, Instagram, Linkedin, Lock, Building2 } from 'lucide-react';
import { Page, Language } from '../types';
import { useContent } from '../contexts/ContentContext';

interface FooterProps {
  setPage: (page: Page) => void;
  language: Language;
}

const Footer: React.FC<FooterProps> = ({ setPage, language }) => {
  const { content } = useContent();
  const t = content.translations[language].footer;
  const navT = content.translations[language].navbar.links;

  return (
    <footer className="bg-slate-950 text-slate-300 pt-16 pb-8 border-t border-slate-900 text-start">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12 mb-12">
          
          {/* Brand Column */}
          <div>
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center text-sky-600 shadow-lg">
                 <Building2 size={28} strokeWidth={1.5} />
              </div>
              <span className="text-xl font-bold text-white">{content.translations[language].common.tawazi}</span>
            </div>
            <p className="text-sm leading-relaxed mb-6 text-slate-400">
              {t.description}
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-sky-500 hover:text-white transition-all duration-300">
                <Twitter size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-sky-500 hover:text-white transition-all duration-300">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-sky-500 hover:text-white transition-all duration-300">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-sky-500 hover:text-white transition-all duration-300">
                <Linkedin size={18} />
              </a>
            </div>
          </div>

          {/* Links Column */}
          <div>
            <h3 className={`text-white font-bold text-lg mb-6 ${language === 'ar' ? 'border-r-4 pr-3' : 'border-l-4 pl-3'} border-sky-500`}>{t.quickLinks}</h3>
            <ul className="space-y-3">
              <li><button onClick={() => setPage(Page.HOME)} className="hover:text-sky-500 transition-colors text-sm">{navT[Page.HOME]}</button></li>
              <li><button onClick={() => setPage(Page.ABOUT)} className="hover:text-sky-500 transition-colors text-sm">{navT[Page.ABOUT]}</button></li>
              <li><button onClick={() => setPage(Page.SERVICES)} className="hover:text-sky-500 transition-colors text-sm">{navT[Page.SERVICES]}</button></li>
              <li><button onClick={() => setPage(Page.GALLERY)} className="hover:text-sky-500 transition-colors text-sm">{navT[Page.GALLERY]}</button></li>
              <li><button onClick={() => setPage(Page.CONTACT)} className="hover:text-sky-500 transition-colors text-sm">{navT[Page.CONTACT]}</button></li>
            </ul>
          </div>

          {/* Services Column */}
          <div>
            <h3 className={`text-white font-bold text-lg mb-6 ${language === 'ar' ? 'border-r-4 pr-3' : 'border-l-4 pl-3'} border-sky-500`}>{t.servicesTitle}</h3>
            <ul className="space-y-3">
              {t.serviceList.map((service: string, index: number) => (
                <li key={index} className="text-sm text-slate-400">{service}</li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-slate-800 pt-8 text-center relative group">
          <p className="text-slate-500 text-sm flex items-center justify-center gap-1">
             {t.copyright} {new Date().getFullYear()} {content.translations[language].common.tawazi}
          </p>
          <div className="absolute bottom-0 right-0 opacity-0 group-hover:opacity-100 transition-opacity p-2">
            <button onClick={() => setPage(Page.ADMIN)} className="text-slate-800 hover:text-slate-600">
                <Lock size={12} />
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;