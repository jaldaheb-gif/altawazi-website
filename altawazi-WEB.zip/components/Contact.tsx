import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, Send } from 'lucide-react';
import { Language } from '../types';
import { useContent } from '../contexts/ContentContext';

interface ContactProps {
  language: Language;
}

const Contact: React.FC<ContactProps> = ({ language }) => {
  const [formState, setFormState] = useState({
    name: '',
    email: '',
    phone: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const { content } = useContent();
  const t = content.translations[language].contact;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    setTimeout(() => {
      setIsSubmitted(true);
      setFormState({ name: '', email: '', phone: '', message: '' });
      setTimeout(() => setIsSubmitted(false), 5000);
    }, 1000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormState({ ...formState, [e.target.name]: e.target.value });
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">{t.title}</h2>
          <p className="text-slate-600 max-w-2xl mx-auto">
            {t.description}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          
          {/* Contact Info */}
          <div className="lg:col-span-1 space-y-8">
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-start">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-sky-100 text-sky-600 rounded-full shrink-0">
                  <Phone size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 mb-1">{t.info.phone}</h3>
                  <p className="text-slate-600" dir="ltr">050 682 1091</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-start">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-sky-100 text-sky-600 rounded-full shrink-0">
                  <Mail size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 mb-1">{t.info.email}</h3>
                  <p className="text-slate-600">info@altawazi.sa</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-start">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-sky-100 text-sky-600 rounded-full shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 mb-1">{t.info.location.title}</h3>
                  <p className="text-slate-600">{t.info.location.address}</p>
                  <p className="text-slate-500 text-sm">{t.info.location.city}</p>
                </div>
              </div>
            </div>

            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-start">
              <div className="flex items-start gap-4">
                <div className="p-3 bg-sky-100 text-sky-600 rounded-full shrink-0">
                  <Clock size={24} />
                </div>
                <div>
                  <h3 className="font-bold text-slate-900 mb-1">{t.info.hours.title}</h3>
                  <p className="text-slate-600">{t.info.hours.weekdays}</p>
                  <p className="text-slate-600">{t.info.hours.weekend}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2 bg-white shadow-xl rounded-3xl p-8 border border-gray-100 text-start">
            <h3 className="text-2xl font-bold text-slate-900 mb-6">{t.form.title}</h3>
            
            {isSubmitted ? (
              <div className="bg-green-50 border border-green-200 text-green-700 p-4 rounded-lg text-center animate-fade-in">
                {t.form.success}
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">{t.form.name}</label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      required
                      value={formState.name}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-sky-500 focus:bg-white focus:ring-2 focus:ring-sky-200 outline-none transition-all"
                      placeholder={t.form.placeholders.name}
                    />
                  </div>
                  <div>
                    <label htmlFor="phone" className="block text-sm font-medium text-gray-700 mb-1">{t.form.phone}</label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      required
                      value={formState.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-sky-500 focus:bg-white focus:ring-2 focus:ring-sky-200 outline-none transition-all"
                      placeholder={t.form.placeholders.phone}
                    />
                  </div>
                </div>
                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">{t.form.emailLabel}</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formState.email}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-sky-500 focus:bg-white focus:ring-2 focus:ring-sky-200 outline-none transition-all"
                    placeholder={t.form.placeholders.email}
                  />
                </div>
                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">{t.form.message}</label>
                  <textarea
                    id="message"
                    name="message"
                    required
                    rows={4}
                    value={formState.message}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg bg-gray-50 border border-gray-200 focus:border-sky-500 focus:bg-white focus:ring-2 focus:ring-sky-200 outline-none transition-all resize-none"
                    placeholder={t.form.placeholders.message}
                  ></textarea>
                </div>
                <button
                  type="submit"
                  className="w-full py-4 bg-slate-900 text-white font-bold rounded-lg hover:bg-slate-800 transition-all duration-300 flex items-center justify-center gap-2 shadow-lg"
                >
                  <Send size={18} />
                  {t.form.submit}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;