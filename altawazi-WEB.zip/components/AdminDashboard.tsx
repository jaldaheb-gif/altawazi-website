import React, { useState } from 'react';
import { useContent } from '../contexts/ContentContext';
import { Page, Language, ProjectItem } from '../types';
import { Save, RotateCcw, Plus, Trash2, Image as ImageIcon, Type, LogOut } from 'lucide-react';

interface AdminDashboardProps {
  setPage: (page: Page) => void;
}

const AdminDashboard: React.FC<AdminDashboardProps> = ({ setPage }) => {
  const { content, updateTranslation, updateNestedTranslation, updateHeroImage, addProject, deleteProject, updateProject, saveChanges, resetToDefaults } = useContent();
  const [activeTab, setActiveTab] = useState<'general' | 'about' | 'services' | 'gallery' | 'contact'>('general');
  const [lang, setLang] = useState<Language>('ar');
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');

  // Simple mock auth
  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (username === 'admin' && password === 'admin123') {
      setIsLoggedIn(true);
    } else {
      alert('Invalid credentials');
    }
  };

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="bg-white p-8 rounded-2xl shadow-xl w-full max-w-md">
          <h2 className="text-2xl font-bold text-center mb-6 text-slate-900">Admin Login</h2>
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Username</label>
              <input 
                type="text" 
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full p-3 border rounded-lg"
                placeholder="admin"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
              <input 
                type="password" 
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full p-3 border rounded-lg"
                placeholder="admin123"
              />
            </div>
            <button type="submit" className="w-full bg-sky-500 text-white py-3 rounded-lg font-bold hover:bg-sky-600 transition">
              Login
            </button>
            <button type="button" onClick={() => setPage(Page.HOME)} className="w-full text-gray-500 py-2 hover:text-gray-700 text-sm">
              Back to Home
            </button>
          </form>
        </div>
      </div>
    );
  }

  const TabButton = ({ id, label, icon: Icon }: any) => (
    <button
      onClick={() => setActiveTab(id)}
      className={`flex items-center gap-2 px-6 py-3 rounded-lg transition-all ${
        activeTab === id 
          ? 'bg-sky-500 text-white shadow-md' 
          : 'bg-white text-gray-600 hover:bg-gray-50'
      }`}
    >
      <Icon size={18} />
      {label}
    </button>
  );

  const InputGroup = ({ label, value, onChange, type = "text", textarea = false }: any) => (
    <div className="mb-4">
      <label className="block text-xs uppercase tracking-wider text-gray-500 font-bold mb-2">{label}</label>
      {textarea ? (
        <textarea
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-sky-500 outline-none min-h-[100px]"
        />
      ) : (
        <input
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-sky-500 outline-none"
        />
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-100 flex flex-col font-sans" dir="ltr">
      {/* Header */}
      <header className="bg-slate-900 text-white p-4 shadow-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto flex justify-between items-center">
          <div className="flex items-center gap-4">
            <h1 className="text-xl font-bold">CMS Dashboard</h1>
            <div className="flex bg-slate-800 rounded-lg p-1">
              <button 
                onClick={() => setLang('ar')}
                className={`px-3 py-1 rounded-md text-sm ${lang === 'ar' ? 'bg-sky-500 text-white' : 'text-gray-400'}`}
              >
                Arabic
              </button>
              <button 
                onClick={() => setLang('en')}
                className={`px-3 py-1 rounded-md text-sm ${lang === 'en' ? 'bg-sky-500 text-white' : 'text-gray-400'}`}
              >
                English
              </button>
            </div>
          </div>
          <div className="flex gap-3">
            <button onClick={resetToDefaults} className="flex items-center gap-2 px-4 py-2 bg-red-500/20 text-red-400 rounded-lg hover:bg-red-500/30 transition">
              <RotateCcw size={16} /> Reset
            </button>
            <button onClick={saveChanges} className="flex items-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition shadow-lg animate-pulse">
              <Save size={16} /> Save Changes
            </button>
            <button onClick={() => setPage(Page.HOME)} className="flex items-center gap-2 px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 transition">
              <LogOut size={16} /> Exit
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-6">
        <div className="flex flex-wrap gap-4 mb-8">
          <TabButton id="general" label="Hero & Main" icon={ImageIcon} />
          <TabButton id="about" label="About Us" icon={Type} />
          <TabButton id="services" label="Services" icon={Type} />
          <TabButton id="gallery" label="Gallery" icon={ImageIcon} />
          <TabButton id="contact" label="Contact" icon={Type} />
        </div>

        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 animate-fade-in-up">
          
          {activeTab === 'general' && (
            <div className="space-y-6">
              <h3 className="text-lg font-bold border-b pb-2">Hero Section</h3>
              <InputGroup 
                label="Background Image URL" 
                value={content.heroImage} 
                onChange={updateHeroImage} 
              />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <InputGroup 
                  label="Title Prefix" 
                  value={content.translations[lang].hero.titlePrefix} 
                  onChange={(v: string) => updateTranslation(lang, 'hero', 'titlePrefix', v)} 
                />
                <InputGroup 
                  label="Title Suffix (Highlighted)" 
                  value={content.translations[lang].hero.titleSuffix} 
                  onChange={(v: string) => updateTranslation(lang, 'hero', 'titleSuffix', v)} 
                />
              </div>
              <InputGroup 
                label="Subtitle" 
                value={content.translations[lang].hero.subtitle} 
                onChange={(v: string) => updateTranslation(lang, 'hero', 'subtitle', v)} 
              />
              <InputGroup 
                label="Description" 
                value={content.translations[lang].hero.description} 
                onChange={(v: string) => updateTranslation(lang, 'hero', 'description', v)} 
                textarea
              />
            </div>
          )}

          {activeTab === 'about' && (
            <div className="space-y-6">
              <h3 className="text-lg font-bold border-b pb-2">About Section</h3>
              <InputGroup 
                label="Title Prefix" 
                value={content.translations[lang].about.titlePrefix} 
                onChange={(v: string) => updateTranslation(lang, 'about', 'titlePrefix', v)} 
              />
              <InputGroup 
                label="Title Suffix" 
                value={content.translations[lang].about.titleSuffix} 
                onChange={(v: string) => updateTranslation(lang, 'about', 'titleSuffix', v)} 
              />
              <InputGroup 
                label="Paragraph 1" 
                value={content.translations[lang].about.description1} 
                onChange={(v: string) => updateTranslation(lang, 'about', 'description1', v)} 
                textarea
              />
              <InputGroup 
                label="Paragraph 2" 
                value={content.translations[lang].about.description2} 
                onChange={(v: string) => updateTranslation(lang, 'about', 'description2', v)} 
                textarea
              />
            </div>
          )}

          {activeTab === 'services' && (
            <div className="space-y-6">
              <h3 className="text-lg font-bold border-b pb-2">Services</h3>
              <InputGroup 
                label="Section Title" 
                value={content.translations[lang].services.title} 
                onChange={(v: string) => updateTranslation(lang, 'services', 'title', v)} 
              />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                 {['general', 'restoration', 'finishing', 'design', 'mep', 'management'].map((key) => (
                    <div key={key} className="p-4 border rounded-lg bg-gray-50">
                        <h4 className="font-bold capitalize mb-2 text-sky-600">{key}</h4>
                        <InputGroup 
                            label="Title" 
                            value={content.translations[lang].services.items[key]?.title} 
                            onChange={(v: string) => updateNestedTranslation(lang, ['services', 'items', key, 'title'], v)} 
                        />
                        <InputGroup 
                            label="Description" 
                            value={content.translations[lang].services.items[key]?.desc} 
                            onChange={(v: string) => updateNestedTranslation(lang, ['services', 'items', key, 'desc'], v)} 
                            textarea
                        />
                    </div>
                 ))}
              </div>
            </div>
          )}

          {activeTab === 'gallery' && (
            <div className="space-y-6">
              <div className="flex justify-between items-center border-b pb-2">
                 <h3 className="text-lg font-bold">Gallery Projects</h3>
                 <button 
                    onClick={() => addProject({ title: 'New Project', category: 'residential', imageUrl: 'https://via.placeholder.com/800' })}
                    className="flex items-center gap-1 text-sm bg-sky-500 text-white px-3 py-1.5 rounded-full hover:bg-sky-600 transition"
                 >
                    <Plus size={16} /> Add Project
                 </button>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {content.projects.map((project) => (
                  <div key={project.id} className="border rounded-xl p-4 bg-white shadow-sm relative group">
                    <button 
                        onClick={() => deleteProject(project.id)}
                        className="absolute top-2 right-2 bg-red-100 text-red-500 p-1 rounded-full opacity-0 group-hover:opacity-100 transition hover:bg-red-200"
                    >
                        <Trash2 size={16} />
                    </button>
                    <div className="mb-3 rounded-lg overflow-hidden h-32 bg-gray-100">
                        <img src={project.imageUrl} alt={project.title} className="w-full h-full object-cover" />
                    </div>
                    <InputGroup 
                        label="Title"
                        value={project.title}
                        onChange={(v: string) => updateProject({ ...project, title: v })}
                    />
                    <div className="mb-4">
                         <label className="block text-xs uppercase tracking-wider text-gray-500 font-bold mb-2">Category</label>
                         <select 
                            value={project.category}
                            onChange={(e) => updateProject({ ...project, category: e.target.value })}
                            className="w-full p-3 border border-gray-200 rounded-lg focus:ring-2 focus:ring-sky-500 outline-none bg-white"
                         >
                             <option value="residential">Residential</option>
                             <option value="commercial">Commercial</option>
                             <option value="restoration">Restoration</option>
                             <option value="decor">Decor</option>
                         </select>
                    </div>
                    <InputGroup 
                        label="Image URL"
                        value={project.imageUrl}
                        onChange={(v: string) => updateProject({ ...project, imageUrl: v })}
                    />
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'contact' && (
             <div className="space-y-6">
              <h3 className="text-lg font-bold border-b pb-2">Contact Info</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <InputGroup 
                    label="Phone Title" 
                    value={content.translations[lang].contact.info.phone} 
                    onChange={(v: string) => updateNestedTranslation(lang, ['contact', 'info', 'phone'], v)} 
                  />
                   <InputGroup 
                    label="Email Title" 
                    value={content.translations[lang].contact.info.email} 
                    onChange={(v: string) => updateNestedTranslation(lang, ['contact', 'info', 'email'], v)} 
                  />
                  <InputGroup 
                    label="Address" 
                    value={content.translations[lang].contact.info.location.address} 
                    onChange={(v: string) => updateNestedTranslation(lang, ['contact', 'info', 'location', 'address'], v)} 
                  />
                   <InputGroup 
                    label="City/Zip" 
                    value={content.translations[lang].contact.info.location.city} 
                    onChange={(v: string) => updateNestedTranslation(lang, ['contact', 'info', 'location', 'city'], v)} 
                  />
              </div>
             </div>
          )}

        </div>
      </main>
    </div>
  );
};

export default AdminDashboard;