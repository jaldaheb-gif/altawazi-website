import React from 'react';
import { Home, Hammer, PaintBucket, PencilRuler, Zap, Truck, PenTool } from 'lucide-react';
import { Language } from '../types';
import { useContent } from '../contexts/ContentContext';

interface ServicesProps {
  language: Language;
}

const Services: React.FC<ServicesProps> = ({ language }) => {
  const { content } = useContent();
  const t = content.translations[language].services;
  
  const iconMap: any = {
    Home: <Home size={40} />,
    Hammer: <Hammer size={40} />,
    PaintBucket: <PaintBucket size={40} />,
    PencilRuler: <PencilRuler size={40} />,
    Zap: <Zap size={40} />,
    Truck: <Truck size={40} />,
    PenTool: <PenTool size={40} />
  };

  return (
    <section className="py-20 bg-slate-900 text-white relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center mb-16">
          <span className="text-sky-500 font-semibold tracking-wide uppercase text-sm">{t.subtitle}</span>
          <h2 className="text-3xl md:text-4xl font-bold mt-2 mb-4">{t.title}</h2>
          <div className="w-24 h-1 bg-sky-500 mx-auto rounded-full"></div>
          <p className="mt-4 text-gray-400 max-w-2xl mx-auto">
            {t.description}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {content.services.map((service) => {
             const itemContent = t.items[service.title] || { title: service.title, desc: service.description };
             return (
              <div 
                key={service.id}
                className="bg-slate-800 p-8 rounded-2xl hover:bg-slate-700 transition-all duration-300 group border border-slate-700 hover:border-sky-500/50 hover:shadow-xl hover:shadow-sky-500/10 text-start"
              >
                <div className="w-16 h-16 bg-slate-900 rounded-xl flex items-center justify-center text-sky-500 mb-6 group-hover:scale-110 transition-transform duration-300 shadow-inner">
                  {iconMap[service.iconName] || <Home size={40} />}
                </div>
                <h3 className="text-xl font-bold mb-3 text-white group-hover:text-sky-400 transition-colors">
                  {itemContent.title}
                </h3>
                <p className="text-gray-400 leading-relaxed">
                  {itemContent.desc}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;