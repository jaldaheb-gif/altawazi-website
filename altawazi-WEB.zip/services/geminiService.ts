import { GoogleGenAI } from "@google/genai";
import { Language } from "../types";

const API_KEY = process.env.API_KEY || '';

// Check if API key exists, but don't crash immediately, let the UI handle the missing key state gracefully if needed
const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateConsultationResponse = async (userQuery: string, lang: Language = 'ar'): Promise<string> => {
  if (!API_KEY) {
    return lang === 'ar' 
      ? "عذراً، خدمة المساعد الذكي غير متوفرة حالياً (API Key missing)."
      : "Sorry, the smart assistant service is currently unavailable (API Key missing).";
  }

  const systemInstructionAr = `
    أنت مساعد ذكي ومستشار بناء لمؤسسة "التوازي الحديثة للمقاولات".
    دورك هو مساعدة العملاء في الاستفسارات المتعلقة بالبناء، التشطيبات، التصميم الداخلي، وتقدير التكاليف بشكل تقريبي.
    تحدث باللغة العربية بأسلوب مهني، ودود، ومختصر.
    إذا سُئلت عن الأسعار، اذكر أنها تقديرية وأن السعر النهائي يحدد بعد المعاينة.
    خدماتنا تشمل: المقاولات العامة، التشطيبات، الترميم، التصميم الداخلي، والكهرباء والسباكة.
  `;

  const systemInstructionEn = `
    You are a smart assistant and construction consultant for "Modern Tawazi Contracting".
    Your role is to assist clients with inquiries related to construction, finishing, interior design, and rough cost estimations.
    Speak in English in a professional, friendly, and concise manner.
    If asked about prices, mention that they are estimates and the final price is determined after inspection.
    Our services include: General Contracting, Finishing, Restoration, Interior Design, and MEP.
  `;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: userQuery,
      config: {
        systemInstruction: lang === 'ar' ? systemInstructionAr : systemInstructionEn,
        temperature: 0.7,
      }
    });

    return response.text || (lang === 'ar' ? "عذراً، لم أتمكن من معالجة طلبك في الوقت الحالي." : "Sorry, I couldn't process your request at this time.");
  } catch (error) {
    console.error("Gemini API Error:", error);
    return lang === 'ar' 
      ? "حدث خطأ أثناء الاتصال بالمساعد الذكي. يرجى المحاولة لاحقاً."
      : "An error occurred while connecting to the smart assistant. Please try again later.";
  }
};